# Public Assets
Place static assets like images, videos, and fonts here.
Files in this directory are served from the root URL (e.g., `/rocket-launch.mp4`).
