// Moved to app/page.tsx
export default function App() { return null; }